<section class="header">

   <a href="home.php" class="logo">travelUp.</a>

   <nav class="navbar">
   <a href="login.php">Login</a>
   <a href="book.php">book</a>
      <a href="home.php">home</a>
      <a href="about.php">about</a>
      <a href="package.php">package</a>
      <a href="book.php">book</a>
   </nav>

   <div id="menu-btn" class="fas fa-bars"></div>

</section>