<?php
session_start();
session_destroy();
header("Location: login.php");
?>

// package.php
<?php include 'header.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <!-- ... -->
</head>
<body>
    <!-- ... -->
</body>
</html>