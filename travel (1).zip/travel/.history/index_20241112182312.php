<?php
// Redirect to home.php
header("Location: home.php");
exit();
?>
