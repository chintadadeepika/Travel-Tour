<?php
// Redirect to home.php
header("Location: register.php");
exit();
?>
