<section class="header">
    <a href="home.php" class="logo">travelUp.</a>

    <nav class="navbar">
        
        <a href="home.php">Home</a>
        <a href="about.php">About</a>
        <a href="package.php">Package</a>
        <a href="book.php">Book</a>
    </nav>

    <div id="menu-btn" class="fas fa-bars"></div>
</section>
