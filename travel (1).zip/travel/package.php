<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>package</title>

   <!-- swiper css link  -->
   <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css" />

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<!-- header section starts  -->

<?php @include 'header.php'; ?>

<!-- header section ends -->

<div class="heading" style="background:url(images/header-bg-2.png) no-repeat">
   <h1>packages</h1>
</div>

<!-- packages section starts  -->

<section class="packages">

   <h1 class="heading-title">top destinations</h1>

   <div class="box-container">

      <div class="box">
         <div class="image">
            <img src="images/img-1.jpg" alt="">
         </div>
         <div class="content">
            <h3>India</h3>
            <p>A hypnotic glance at the iconic masterpiece of all time when the first rays of sun hits the dome shaped beauty.</p>
            <a href="book.php" class="btn">book now</a>
         </div>
      </div>

      <div class="box">
         <div class="image">
            <img src="images/img-2.jpg" alt="">
         </div>
         <div class="content">
            <h3>Seychelles</h3>
            <p>Escape to an island paradise with white beaches all around. Enjoy the full day tour of La Digue Island & a romantic dinner in Praslin.</p>
            <a href="book.php" class="btn">book now</a>
         </div>
      </div>

      <div class="box">
         <div class="image">
            <img src="images/img-3.jpg" alt="">
         </div>
         <div class="content">
            <h3>Iceland</h3>
            <p>A Holiday you wish would never end, just like a summer day in Iceland. Add a Puffin, ATV tours and much more under the Midnight Sun.</p>
            <a href="book.php" class="btn">book now</a>
         </div>
      </div>

      <div class="box">
         <div class="image">
            <img src="images/img-4.jpg" alt="">
         </div>
         <div class="content">
            <h3>Japan</h3>
            <p>The stunning cherry blossoms, attending fairs & festivals in Tokyo and heavy-off season discounts on flights & hotels in Osaka.</p>
            <a href="book.php" class="btn">book now</a>
         </div>
      </div>

      <div class="box">
         <div class="image">
            <img src="images/img-5.jpg" alt="">
         </div>
         <div class="content">
            <h3>New York</h3>
            <p>Exploring the parks, walking tous, rains in spring, dining & boating in New York, pleasant weather at night & clear blue skies in LA.</p>
            <a href="book.php" class="btn">book now</a>
         </div>
      </div>

      <div class="box">
         <div class="image">
            <img src="images/img-6.jpg" alt="">
         </div>
         <div class="content">
            <h3>Australia</h3>
            <p>Hosts some of the best, and most iconic, breaks in the surfing world. Surfing pioneer country.</p>
            <a href="book.php" class="btn">book now</a>
         </div>
      </div>

      <div class="box">
         <div class="image">
            <img src="images/img-7.jpg" alt="">
         </div>
         <div class="content">
            <h3>Switzerland</h3>
            <p>Exploring the outdoors & touring the lovely city Lucerne & Zurich, touring vineyards and enjoying the grape harvest season in Interlaken.</p>
            <a href="book.php" class="btn">book now</a>
         </div>
      </div>

      <div class="box">
         <div class="image">
            <img src="images/img-8.jpg" alt="">
         </div>
         <div class="content">
            <h3>Austria</h3>
            <p>Trips in and around the town of Salzburg will let tourists relive the movie. Tourists can indulge in skiing in Innsbruck and hiking in the innumerable national parks.</p>
            <a href="book.php" class="btn">book now</a>
         </div>
      </div>

      <div class="box">
         <div class="image">
            <img src="images/img-9.jpg" alt="">
         </div>
         <div class="content">
            <h3>Thailand</h3>
            <p>Sightseeing and shopping in Phuket and adventure activities in Pattaya. Rain and pub hopping in Krabi and escaping the crowds & lush green surroundings in Phuket.</p>
            <a href="book.php" class="btn">book now</a>
         </div>
      </div>

      <div class="box">
         <div class="image">
            <img src="images/img-10.jpg" alt="">
         </div>
         <div class="content">
            <h3>Dubai</h3>
            <p>Pamper yourself with luxury stays, breathtaking views and more in Dubai.</p>
            <a href="book.php" class="btn">book now</a>
         </div>
      </div>

      <div class="box">
         <div class="image">
            <img src="images/img-11.jpg" alt="">
         </div>
         <div class="content">
            <h3>Maldives</h3>
            <p>Relish the lovely Maldives with snorkelling and chasing the sunsets on Meeru Island.</p>
            <a href="book.php" class="btn">book now</a>
         </div>
      </div>

      <div class="box">
         <div class="image">
            <img src="images/img-12.jpg" alt="">
         </div>
         <div class="content">
            <h3>Norway</h3>
            <p>Indian meals in Scandinavian Region, Norway in a Nut Shell Tour, Overnight Ferry experience.</p>
            <a href="book.php" class="btn">book now</a>
         </div>
      </div>

   </div>

   <div class="load-more"><span class="btn">load more</span></div>

</section>

<!-- packages section ends -->



<!-- footer section starts  -->

<?php @include 'footer.php'; ?>

<!-- footer section ends -->




<!-- swiper js link  -->
<script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>

<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>